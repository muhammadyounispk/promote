
import { getSession, getChatList, isExists, sendMessage, formatPhone,isSessionExists } from './../whatsapp.js'
import response from './../response.js'
import axios from 'axios';
import mysql from 'mysql';
import { emitWarning } from 'process';

var connection = mysql.createConnection({
  host     : '64.31.43.242',
  user     : 'isdigita_school',
  password : 'Younis786@',
  database : 'isdigita_marketing'
});


const getList = (req, res) => {
    return response(res, 200, true, '', getChatList(res.locals.sessionId))
}

const send = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatPhone(req.body.receiver)
    const delay = req.body.delay
    const { message } = req.body

    try {
        const exists = await isExists(session, receiver)

        if (!exists) {
            return response(res, 400, false, 'The receiver number is not exists.')
        }
        // console.log(message);
        // console.log(session);
        console.log(receiver);
        await sendMessage(session, receiver,message, delay)

        response(res, 200, true, 'The message has been successfully sent.')
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}

  
async function PerformJob(user_id) {
  let counter = 0;
  const job=setInterval(() => {
    counter++;

   
   connection.query('SELECT* from devices where user_id='+user_id+' and status=1 ', function (error, devices  , fields) {
    const no_record=devices.length
    const limit=devices.length
  
    console.log(`[-------------------  SERVICE # ${counter}  PROCESSING BY USER ${user_id} OVER ${limit} WHATSAPP NO.   ------------------------]`)
   if(no_record>0){
    connection.query('SELECT* , file as attachment , message as text from promotion_jobs where user_id='+user_id+' and is_completed=0 order by id limit '+limit, function (error, messages, fields) {
     if(messages.length>0){
      const data = [];
      const totalDevices = limit;
      const totalMessages = limit;
      const messagesPerDevice = Math.ceil(totalMessages / totalDevices);
      const chunkedMessages = [];
      for (let i = 0; i < totalMessages; i += messagesPerDevice) {
          chunkedMessages.push(messages.slice(i, i + messagesPerDevice));
      } 


      let index = 0;
    devices.forEach((device) => {
      const deviceMessages = chunkedMessages[index] || [];
      const myMessages = [];
      
      deviceMessages.forEach((message) => {
        myMessages.push(message);
      });

      data[device.id] = myMessages;
      index++;
    });

  // sending messages 
  data.forEach(async (msgArr,key) => {
    //Sending 
    const item=msgArr[0]
    const to = item.phone;
    const message = item.message;
    const type = item.type;
    const id = item.id;
    const job = item.job;
    const user_id = item.user_id;
    const delay = item.delay;
    const from = item.from;
    const device_id = key
    const footer = item.footer;
    var  session = getSession('device_'+device_id)
 
    try{
      const exists = await isExists(session, to)
      if(exists){
 
        
      const msg=formatArray(item, message, type);
      console.log(msg);
      const receiver = formatPhone(to)
      if (type === 'plain-text') {
      msg.text=msg.text+"\n--------\n"+footer+"\n[MID:"+id+"]";
      }else{
        msg.caption=msg.caption+"\n--------\n"+footer+"\n[MEDIA-MID:"+id+"]";
      }
      await sendMessage(session,receiver , msg, delay)
      connection.query('UPDATE promotion_jobs SET   is_completed = ?, device_id=? WHERE id =?', [1 , key, id], function (error, results, fields) {  });
      console.log(type+")-- WHATSAPP SENT [MSGID "+id+"]FROM DEVICE ID "+key);
      //SAVING TRANSACTION
      var smstransactions ={user_id: user_id, from: from,to:to,type:job,device_id:key}
      connection.query('INSERT INTO smstransactions SET ?', smstransactions, function (error, results, fields) {});
      }else{
        connection.query('UPDATE promotion_jobs SET   is_completed = ? ,exception=? ,device_id=? WHERE id =?', [2 , 'NUMBER NOT EXIST ON WHATSAPP',key, id], function (error, results, fields) {  });
       
      }

    }catch(err){
      connection.query('UPDATE promotion_jobs SET   is_completed = ? , exception=? , device_id=? WHERE id =?', [3 , 'ERROR '+err,key, id], function (error, results, fields) {  });
      console.log("ERROR"+err);
     

    }

  });
     



    }else{
      clearInterval(job); // Clear the interval
      console.log("###############################--- CLOSED----#################################");
    }
  


  })


    }else{
      clearInterval(job); // Clear the interval
      console.log("###############################--- CLOSED----#################################");

    }

 


 });



 

}, 5000);

 return ;



if(limit>0){
connection.query('SELECT count(*) as jobs from promotion_jobs where user_id='+user_id+' and is_completed=0 order by id ', function (error, results, fields) {
 
  if (results[0].jobs > 0) {
    
    setInterval( () => {

     
 
      
    }, 5000);
    
} else {
    console.log('No jobs found for the user.');
}

});
}
  return

  
}


const sendPromote = async (req, res) => {
   response(res, 200, true, 'Request is processing, we will keep you updated');

  const limit = req.body.packet.limit
  const devices = req.body.packet.devices
  const user_id = req.query.id
  
  PerformJob(user_id);


  return 
  var do_reload=false;
  var refresh_url="";
  for (const key in payload) {

    if (!isSessionExists("device_"+key)) {
      console.log(key+"  not  exists "); // Output: '0', '1', '2'
      do_reload=true;
      refresh_url=payload[key];
      connection.query('UPDATE devices SET   status = ?  WHERE id =?', ['0' , key], function (error, results, fields) {  });

    }

  }

  
if(do_reload){
    console.log("--------------REFRESH-REQUEST-----------------");
    axios.get(refresh_url)
    .then(response => {
     console.log("----------REFRESH-DONE---------------");

    }) .catch(error => {
     console.error('Error reading file:', error.message);
   });
   console.log("---------- NOW CONTINUE WITH NEW REQUEST ------ ");
   return;
}else{
  console.log("---------- EVERYTHING IS FINE ------ ");
}


  for (const key in payload) {
  const url=payload[key];
  
  var  session = getSession('device_'+key)
  console.log(key+url);
  axios.get(payload[key])
  .then( async response => {
    const packet=response.data;
    console.log(" ------ TOTAL "+packet.length+" @   "+key+' --------'); // Output the content of the file

  
    for (let index = 0; index < packet.length; index++) {
        const item = packet[index];
        const to = item.phone;
        const message = item.message;
        const type = item.type;
        const id = item.id;
        const user_id = item.user_id;
        const delay = item.delay;
        const from = item.from;
        
        const job = item.job;
        const footer = item.footer;
        const callBack = item.callBack;
        try{
      
  
        const exists = await isExists(session, to)
  
        
  
        if(exists){
        const msg=formatArray(item, message, type);
        const receiver = formatPhone(to)
        msg.text=msg.text+"\n--------\n"+footer+"\n[MID:"+id+"-"+(index+1)+"]";
        await sendMessage(session,receiver , msg, delay)
        connection.query('UPDATE promotion_jobs SET   is_completed = ?, device_id=? WHERE id =?', [1 , key, id], function (error, results, fields) {  });
        console.log("[MSGID DONE "+(index+1)+"]  FROM "+key);
        //SAVING TRANSACTION
        var smstransactions ={user_id: user_id, from: from,to:to,type:job,device_id:key}
        connection.query('INSERT INTO smstransactions SET ?', smstransactions, function (error, results, fields) {});
  
  
        }else{
          connection.query('UPDATE promotion_jobs SET   is_completed = ? ,exception=? ,device_id=? WHERE id =?', [2 , 'NUMBER NOT EXIST ON WHATSAPP',key, id], function (error, results, fields) {  });
         
        }
  
      }catch(err){
        connection.query('UPDATE promotion_jobs SET   is_completed = ? , exception=? , device_id=? WHERE id =?', [3 , 'ERROR '+err,key, id], function (error, results, fields) {  });
        console.log("ERROR"+err);
        var reload=true;
  
      }
  
        await slowme(delay);
        
  
  
    }
  
 
  
  
  }).catch(error => {
    console.error('Error reading file:', error.message);
  });
  

 
  
}
console.log("--END--");


}








function slowme(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}


function formatArray(data, message, type) {
    const content = {};
  
    if (type === 'plain-text') {
      content.text = message;
    } else if (type === 'text-with-media') {
      content.caption = message;
      const fileExtension = data.attachment.split('.').pop().toLowerCase();
      const extensions = {
        jpg: 'image',
        jpeg: 'image',
        png: 'image',
        webp: 'image',
        pdf: 'document',
        docx: 'document',
        xlsx: 'document',
        csv: 'document',
        txt: 'document'
      };
  
      const fileType = extensions[fileExtension];
      if (fileType) {
        content[fileType] = { url: data.attachment };
      }
    }
    
  
    return content;
  }
  




const sendBulk = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const errors = []

    for (const [key, data] of req.body.entries()) {
        let { receiver, message, delay } = data

        if (!receiver || !message) {
            errors.push(key)

            continue
        }

        if (!delay || isNaN(delay)) {
            delay = 1000
        }

        receiver = formatPhone(receiver)

        try {
            const exists = await isExists(session, receiver)

            if (!exists) {
                errors.push(key)

                continue
            }

            await sendMessage(session, receiver, message, delay)
        } catch {
            errors.push(key)
        }
    }

    if (errors.length === 0) {
        return response(res, 200, true, 'All messages has been successfully sent.')
    }

    const isAllFailed = errors.length === req.body.length

    response(
        res,
        isAllFailed ? 500 : 200,
        !isAllFailed,
        isAllFailed ? 'Failed to send all messages.' : 'Some messages has been successfully sent.',
        { errors }
    )
}

export { getList, send, sendBulk,sendPromote }
